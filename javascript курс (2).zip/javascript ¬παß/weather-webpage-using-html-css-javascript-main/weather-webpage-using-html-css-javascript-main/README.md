# weather-webpage-using-html-css-javascript
this is a simple weather webpage project using html, css &amp; javascript. 
